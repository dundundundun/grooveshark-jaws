LastFM + Grooveshark Extension
==========================

A chrome extension to use LastFM data to build Grooveshark playlists. 

### Installation

Bring up the extensions management page in Settings > Extensions.

Toggle developer mode.

Click the Load unpacked extension button.

Navigate to LastFMGroovesharkExtension folder and click OK. 

### Usage

Open www.grooveshark.com

Click the LastFM + Grooveshark chrome extension icon

Enter a LastFM User ID and click submit

Grooveshark will populate with user's LastFM loved tracks. 
