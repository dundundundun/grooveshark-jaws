<script id="byline" type="text/html">
	<a href={{artistURL}} class="artist-link" title="{{artistTitle}}">by {{artistTitle}}</a>
</script>